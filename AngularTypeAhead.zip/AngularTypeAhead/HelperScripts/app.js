﻿(function () {
    var app = angular.module("appMain", ["uni-search", "common.services"]);
}());