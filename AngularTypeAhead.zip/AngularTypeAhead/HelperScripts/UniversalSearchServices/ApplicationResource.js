﻿(function () {
    "use strict";
    var common = angular.module("common.services");
    //var productResourceService = function ($resource) {
    //    var appData = [
    //       {
    //           "ActivityKey": 1,
    //           "ActivityName": "Highfly",
    //           "tags": ["Adventure", "Sikkim", "Paragliding"]
    //       },
    //       {
    //           "ActivityKey": 2,
    //           "ActivityName": "Paragliding",
    //           "tags": ["Adventure", "Sikkim", "Paragliding"]
    //       }
    //    ];

    //    return appData;
    //    //return $resource("api/applicationdata/:id");
    //};    

    var productService = function ($http) {

        var getApplicationData = function (filter) {

            var appData = [
               {
                   "ActivityKey": 1,
                   "ActivityName": "Highfly",
                   "tags": ["Adventure", "Sikkim", "Paragliding","Highfly"]
               },
               {
                   "ActivityKey": 2,
                   "ActivityName": "Trekking",
                   "tags": ["Adventure", "Sikkim", "Trekking","Trekking"]
               },
               {
                   "ActivityKey": 1,
                   "ActivityName": "Highfly-Darjeeing",
                   "tags": ["Adventure", "Darjeeing", "Paragliding", "Highfly Darjeeing"]
               },
               {
                   "ActivityKey": 2,
                   "ActivityName": "Trekking-Darjeeing",
                   "tags": ["Adventure", "Darjeeing", "Trekking", "Trekking"]
               }
            ];

            var result = [];

            for (var i = 0; i < appData.length; i++) {
                for (var j = 0; j < appData[i].tags.length; j++) {
                    if (appData[i].tags[j].match(filter.selected) != null) {
                        result.push(appData[i]);
                        break;
                    }                       
                }
            }

            return result;
        }

        return {
            getApplicationData: getApplicationData,
        }
    }
    //common.factory("applicationResource", ["$resource", productResourceService]);
    common.factory("ApplicationResource", ["$http", productService]);
}());