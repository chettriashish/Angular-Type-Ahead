﻿(function () {
    "use strict";

    var app = angular.module("productResourceMock", ["ngMockE2E"]);

    app.run(function ($httpBackend) {

        var appData = [
            {
                "ActivityKey": 1,
                "ActivityName": "Highfly",
                "tags": ["Adventure", "Sikkim", "Paragliding"]
            },
            {
                "ActivityKey": 2,
                "ActivityName": "Paragliding",
                "tags": ["Adventure", "Sikkim", "Paragliding"]
            }
        ];

        var applicationUrl = "api/applicationdata";

        $httpBackend.whenGET(applicationUrl).respond(appData);
    });
}());