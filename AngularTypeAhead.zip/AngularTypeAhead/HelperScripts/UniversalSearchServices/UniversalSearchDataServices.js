﻿(function () {
    "use strict"
    angular.module("common.services", ["ngResource"]);    
}());