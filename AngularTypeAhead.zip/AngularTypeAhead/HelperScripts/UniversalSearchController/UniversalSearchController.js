﻿(function () {
    var app = angular.module("appMain");

    var universalSearchController = function ($scope, ApplicationResource) {

        $scope.getApplicationData = function (filter) {
            $scope.applicationData = ApplicationResource.getApplicationData(filter);
        }
        $scope.showResult = function (filter) {
            console.log(filter);
        }
    }
    app.controller("UniversalSearchController", ["$scope", "ApplicationResource", universalSearchController]);
}());